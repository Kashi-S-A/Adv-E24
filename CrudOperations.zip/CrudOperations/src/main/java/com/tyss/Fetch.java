package com.tyss;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Fetch {

	public static void main(String[] args) {
		String url = "jdbc:postgresql://localhost:5433/college";
		String user = "postgres";
		String pass = "root";
		String driver = "org.postgresql.Driver";

		try {
			Class.forName(driver);

			Connection con = DriverManager.getConnection(url, user, pass);

			Statement stm = con.createStatement();

//			String query = "UPDATE student SET name='Penga XYZ' WHERE sid=1";
//			
//			boolean result1 = stm.execute(query);
//			System.out.println(result1);//false
			
			String sql = "SELECT * FROM student";
//
//			boolean result = stm.execute(sql);//true
//			System.out.println(result);
			
			ResultSet rs = stm.executeQuery(sql);
			
			System.out.println("-----------All------------");
			
			while (rs.next()) {
				int sid = rs.getInt(1);
				String name = rs.getString(2);
				String add = rs.getString(3);
				long phone = rs.getLong(4);
				
				System.out.println(sid);
				System.out.println(name);
				System.out.println(add);
				System.out.println(phone);
				System.out.println("==================");
			}
			
			con.close();

			System.out.println("Record is fetched and connection is closed");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
