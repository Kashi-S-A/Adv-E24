package com.tyss;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Update {

	public static void main(String[] args) {
		String url = "jdbc:postgresql://localhost:5433/college";
		String user = "postgres";
		String pass = "root";
		String driver = "org.postgresql.Driver";

		try {
			Class.forName(driver);

			Connection con = DriverManager.getConnection(url, user, pass);

			Statement stm = con.createStatement();

			String query = "UPDATE student SET name='Penga XYZ' WHERE sid=1";

			stm.execute(query);

			con.close();

			System.out.println("Record is updated and connection is closed");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}
	}
}
