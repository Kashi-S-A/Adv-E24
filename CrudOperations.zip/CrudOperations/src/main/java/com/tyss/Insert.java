package com.tyss;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class Insert {

	public static void main(String[] args) {
		String url = "jdbc:postgresql://localhost:5433/college";
		String user = "postgres";
		String password = "root";

		try {
			// step 1 : Load the driver
			Class.forName("org.postgresql.Driver");
			System.out.println("Driver is loaded");

			// step 2 : Create Connection
			Connection con = DriverManager.getConnection(url, user, password);
			System.out.println("connection is created");
			
			//step 3 : Create Statement
			Statement stm = con.createStatement();
			System.out.println("Statement is created");
			
			String query="INSERT INTO student VALUES(222,'Johnson','Canada',3456765)";
			
			//step 4 : Execute the query
			stm.execute(query);
			System.out.println("query got executed");
			
			//step 5 : close the connection
			con.close();
			System.out.println("connection is closed");

		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} catch (SQLException e) {
			e.printStackTrace();
		}

	}
}
